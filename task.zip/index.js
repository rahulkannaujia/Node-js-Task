const express = require('express');
require('./Database/db');
const app = express();
const fs = require('fs');
const path = require('path');
multer = require("multer");
app.set("view engine", "ejs");
const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT,    PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});

app.get('/', (req, res) => {
    res.json({"message": "Wellcome!"});
});


const childs = require('./Controlers/child-controler');
const AddressModels = require('./Controlers/address-controler');
const Auth = require('./Controlers/Auth-controler');
// set Api routes...
app.use('/api', childs);
app.use('/api', AddressModels);
app.use('/api', Auth);
// set port, for Server Start...
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});