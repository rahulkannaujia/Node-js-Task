const MongoClient = require('mongoose');
var connectionString = 'mongodb+srv://rahulkumar:Pro%401234%23@cluster0.zha1l.mongodb.net/arivanidemo?retryWrites=true&w=majority'
MongoClient.connect(connectionString, {
  useNewUrlParser: true, useUnifiedTopology: true
}, (error, client) => {
  if (!error) {
    console.log(' Connection Successfully with MongoDB')
  }
  else {
    console.log('Failed to Connection with MongoDB with Error: ' + error)
  }
})

module.exports = MongoClient;