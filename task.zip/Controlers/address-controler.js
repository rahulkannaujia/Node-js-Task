const express = require('express');
const router = express.Router();
const SatateSchema = require('../Models/state');
const DistrictSchema = require('../Models/district');

// Get All State data 
router.get('/state/fetch', async(req, res, next) => {
    SatateSchema.find({}).then((data) => {
     if(data){
        res.send(JSON.stringify({data, status: true }));
     }else{
        res.send(JSON.stringify({ message: 'oops!', status: false }));
     }

    }).catch(next);
});


// insert State data 
router.post('/state/insert', async(req, res, next) => {
      const SatateSchemas = new SatateSchema({
        state_name: req.body.state_name,
      });
      SatateSchemas.save().then((result) => {
          res.send(JSON.stringify({ message: 'State insert successfully', status: true }))
      }).catch(next);
});


// Get All District data 
router.get('/disterict/fetch', async(req, res, next) => {
    DistrictSchema.find({}).then((data) => {
     if(data){
        res.send(JSON.stringify({data, status: true }));
     }else{
        res.send(JSON.stringify({ message: 'oops!', status: false }));
     }

    }).catch(next);
});


// insert State data 
router.post('/disterict/insert', async(req, res, next) => {
      const District = new DistrictSchema({
        state_name: req.body.state_name,
        district_name:req.body.district_name
      });
      District.save().then((result) => {
          res.send(JSON.stringify({ message: 'State insert successfully', status: true }))
      }).catch(next);
});





module.exports = router;