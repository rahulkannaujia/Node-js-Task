const express = require('express');
const router = express.Router();
const ChildRecord = require('../Models/child');

const fs = require('fs');
const path = require('path');
const multer = require('multer');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now())
    }
});

const upload = multer({ storage: storage });



// Get All Child data 
router.get('/child/fetch', async(req, res, next) => {
    var mysort = { date: -1 };
    ChildRecord.find().sort(mysort).then((data) => {
     if(data){
        res.send(JSON.stringify({data, status: true }));
     }else{
        res.send(JSON.stringify({ message: 'oops!', status: false }));
     }

    }).catch(next);
});

// Get Single Child data by Id... 
router.get('/child/single/:id', async(req, res, next) => {
   ChildRecord.findOneAndUpdate({_id: req.params.id},req.body).then((data) => {
    if(data){
       res.send(JSON.stringify({data, status: true }));
    }else{
       res.send(JSON.stringify({ message: 'oops!', status: false }));
    }

   }).catch(next);
});


// insert All Child data 
router.post('/child/insert',upload.single('image'), async(req, res, next) => {
      const ChildRecords =  new ChildRecord({
          full_name: req.body.full_name,
          gender: req.body.gender,
          dob: req.body.dob,
          father_name: req.body.father_name,
          mother_name: req.body.mother_name,
          state: req.body.state,
          district: req.body.district,
          image: {
            data: fs.readFileSync(path.join(useras + '/uploads/' + req.file.filename)),
            contentType: 'image/jpg'
        }
      });
      ChildRecords.save().than(result => {
          res.send(JSON.stringify({ message: 'Child insert successfully', status: true }))
      }).catch(next);
  })





module.exports = router;