const express = require('express');
const router = express.Router();
const UsersRecord = require('../Models/users');
const UsersToken = require('../Models/userValid');
const bcrypt = require('bcryptjs');
require('dotenv').config();
const jwt = require("jsonwebtoken");


// insert All User data 
router.post('/user/insert', async (req, res, next) => {
    const Users = new UsersRecord({
        full_name: req.body.full_name,
        email: req.body.email,
        password: bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(10)),
        gender: req.body.gender,
    });
    Users.save().then((result) => {
        res.send(JSON.stringify({ message: 'Users insert successfully', status: true }))
    }).catch(next);
})

// User Login 
router.post('/user/login', async (req, res, next) => {
    var email = req.body.email;
    const password = req.body.password;
    if (!password && !email) {
        return res.send({ "Message": "Provide Email & Password", "Status": false })
    } else {
        UsersRecord.findOne({ email: email }).then((result) => {
            if (result) {
                const comparision = bcrypt.compareSync(password, result.password);
                if (comparision) {
                    var token = jwt.sign({ result }, process.env.DB_AUTH_SECRET, { expiresIn: "24h" });
                    const UsersValid = new UsersToken({
                        token: token,
                    });
                    UsersValid.save().then((res) => { })
                    return res.send(
                        {
                            "Message": "Login Successfully",
                            "Status": true,
                            token: token,
                            full_name: result.full_name,
                            id: result.id,
                            email: result.email
                        })
                }
                else {
                    return res.send({
                        "Status": false,
                        "Message": "Email and password does not match"
                    })
                }
            } else {
                return res.send({
                    "Status": false,
                    "Message": "Invalid User"
                });
            }
        })
    }
})


// User Logout
router.post('/user/logout', async (req, res, next) => {
    var token = req.body.token;
    console.log(token)
    if (!token) {
        return res.send({ "Message": "Provide Token", "Status": false })
    } else {
        UsersToken.deleteOne({ token: token }).then((result) => {
            if (result) {
                res.send({
                    "Status": true,
                    "Message": "User Logout Successfully"
                });
                console.log(result)
            } else {
                return res.send({
                    "Status": false,
                    "Message": "Invalid Token"
                });
            }
        })
    }
})


module.exports = router;