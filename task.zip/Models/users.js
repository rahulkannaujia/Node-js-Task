const mongoose = require("mongoose");
const UsersRecord = mongoose.Schema({
  full_name: { type: String, required: true },
  email: { type: String, required: true },
  password: { type: String, required: true },
  gender: { type: String, required: true },
  date: { type: Date, default: Date.now() }
});

module.exports = mongoose.model("UsersRecord", UsersRecord);