const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DistrictSchema = new Schema({
    state_name: { type: String, required: true },
    district_name: { type: String, required: true },
    date: { type: Date, default: Date.now() }
});

 
module.exports = mongoose.model('DistrictSchema', DistrictSchema);