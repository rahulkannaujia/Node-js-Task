const mongoose = require("mongoose");
const ChildRecord = mongoose.Schema({
  full_name: { type: String, required: true },
  gender: { type: String, required: true },
  dob: { type: String, required: true },
  father_name: { type: String, required: true },
  mother_name: { type: String, required: false },
  state: { type: String, required: true },
  district:{ type: String, required: true },
  image:{ data: Buffer, contentType: String},
  date: { type: Date, default: Date.now() }
});

module.exports = mongoose.model("ChildRecord", ChildRecord);